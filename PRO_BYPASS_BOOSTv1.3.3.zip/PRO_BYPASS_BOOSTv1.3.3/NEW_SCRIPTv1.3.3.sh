#!/system/bin/sh
##################################################################################
##################################################################################
FREE=$(sync; echo 3 > /proc/sys/vm/drop_caches;free -m | grep 'Mem:' | awk -F' ' '{print $4}')
BU="./backup"
RED=$'\e[1;31m'
grn=$'\e[1;32m'
yel=$'\e[1;33m'
blu=$'\e[1;34m'
mag=$'\e[1;35m'
cyn=$'\e[1;36m'
end=$'\e[0m'
DATA="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAACAASURBVHiczLx5kGXXfd/3+Z1z7n376/d6756tZx8AQ4AgNgIguFOUbAspySJlOZYsqSQmqViOlahSUcWpgmzFdiWOUpHD2JSSiJKlRCEls0TZZCguoAguAAhhncEAg9lnerqn17e/u5wlf9zXAyiWJSUhpXTVq35dc+e9e7/nt3x/39/vHOH/Jz8//uM/Xm5F2al6VT1U0+k7G5VwXz3miJFQi0pCrRZTi4Ug0BtmDPs5aS6M0kBnYMMwDYMoLr8eVPzsOPVP3eoMv/kvP/2vVwH3l/1sAPKX8Z2f+MTHzF2mVc4rndL6TvuHqzr76VZpfLI9FUqt2abUZ9vElSaI4HyOzx02szhncdahnMUnGSiHIaA84D1JkjLojxiMLNbHXsX1gSnXv6aj+H+tZcnXR1P56O7ug4l89KN/4eD/hQH9xBNPqCMLg9mmShZaU613Rcr9XCUaHZlfaFKbruOcZ9wd0d3qs7vVY2Ojw8atDba2dhn0+1jrcB6M1iS5p9MZ4kKg3W7TaDRYWJhjbrrG/Eydxbk6jYpCK8d4nJCkFl1uUa1Pfwncv5Akf6516ERn+v7/oPsX9fzfdaB/+Zd/pnTA5UtTM41DmY5/ca6W3r9vfzuOphrKDrvceuMi1964xObGLh5Bi8Jbi88DwzSnn2T0xynjJODyQK1qiExEp9snjgyLc1N0OwO8D1jn8EERxTG1RoMjx46wON+gGlvqFYOSQO58aLYW+pWp6f/NkH2iOr9vvXbn5obIE/67icN3Degnn3jC9JrXV1rLcw/Fpfinp5u8s9EqlYIPbF25ws03LrLT6ZLmAa0Nu7sDdnZH7O72SDJLpVqiNTNFa7qKNoIghODxmQcFwYPRCqVBRMAHxuOULE3RQRACShky64GIuflFWq0G9ZpirhVTrcahPbfcL7enP1uebv5aeXnhdal+dPW7hcd3HOgnnnhCvW3q5kJ7vvlgo1b66Var9IF6u1ZKe7ty7eyrbK2uk4eI7sixsdllfe0WipypZoXZuTZaCQSP0YZ6rUa73aRcKaEjjRIBFKIVwVuCdxA8zjmc89jMkmYp3f6Q4ThBidDd7TPojYijEus7I0xUZeXgPvYvNlg50GJubiq0Vg7tlGfmPxOi+NfH48Yr00c/+h0PKd9RoD/1Sz9badTcfe2F6kdaM42/XollX9bvsnPtGqvX11nfTtjpJPR7A/q9XaZbZQ4fXmC23cBooVyroUzEcGzZ3OqyuT2k10vpjy2jzJHlDpd7EHBZQilWVEqKWrXEbLvO3GyDuZkGU1UD1jIajtjY6rHbG9MdpWxtden0UmrVmLKJWZhpcPzwLEePL7GwciCUZ5deU43Z37TlxmdmltR5ke9c0vxOAS2f++Wf2Tc1U/3xuYNT3x/H4X477Kvta9e4fvUWl1b73Nzs0d3qMtPQHF5pcefpIxitCKIZjBxXr2+yuj5gbXvEViejM8oY5QFnBevAKyFQhAgfPOlgiDEBURBpQzlSVCOhXtFM1wyzUxHLczWWpqtUDHT6Y7Z2M7qjMZkLrG91aVXLNMow365zZGWBpQMLzBxayZr7D365Mr38yTw1X/hOWff/Z6CfeOIJ9fhp3lFp+L/XWGj/tZB0p3auX6O7sc3zr61z4eou3U6f5YbhzlNLnL7/FBJyBiPP+ctbvHFpk/WtMVvdlF7iSXKP80JuPS4EvBeChyAgWuEC2DwlH40xSoEIRiu0Ai2C1mA0lDRUY2GqalhoGA7Ml9g326QUeYIqs7o14NZWh63tAfPtCvWyolWvsLRvmiN3neTgHSfP1Q+d+kKlNvXfSO171/7Sgb76rX/6t6utyk8K9tHhxnW9dWWVNy5u8Pr1Hba3O1SV49jhWe65/w5qtTI7uykvvnKV1y7scGOrTy8B6yGznjT3WOdxTvDeFZbsi2QXgCCCF7B5hk3GaBUhAbQWRBxaCUqpAnAlKAFjhJIONMvCTNNwdL7K6eNzzExVGKSWa6tdrt7YIbc57bqmrDXzc02O33GYU488MJo9durzuj73C8QfPCMi4S8F6K2XPv6L1fnqj2Sj/pGNc2fYXevw7MvXubrRYb6uma0bTpw+wvzyLFudMc+/cI2z57dY3x4xSGGcWawPOA9ZZskseMA7j/O+sOYghACBUIQOo7FZik0TRGvEB5RSKPGIFFatJiALCqMFrcBowUigUYbFdswd+2ucPjbP0lKL7jDn1ddvcn11k2ZFUTLCvsVZjh7fx9u+5z2+fvDt3zLl+b8v0QNf/QsFOoRPxclm/HFl+j+UdbamNs+cldUbW3z9has4N+LwdI2FhVn2nVjBB+GFl6/w3JmbXFnt008C1gWcC4ysw1mPD0KWWXzQWB/w3uF8wLtACOAndhREEcTg8jHeZqAU4gt6CB6RgJICZKUEhaAUGAVKKYwIWgciLbSrmv3TEe+4Y5r7T++n2Wjy2vlVXj53mXIMc+0qRw4uc/jOgyw98v4QT514TVTzH5jSPb/9/wYz8/8c5CBu/JVPmtru4/n6rVrn9de5/MYaX33+NQ4v15iuNplZWuDQHae4cnGdr37jDc5e2mZ7mJPnYG3A+kBmHdZDngecc+S5wxPwAawL+AngIQRCEEQpXHBEsSF3AQ+I9+DBBY+oYjXEe7SmAFtAicJrQcTjtKCDYD24Yc4gtWwObrG6Mea99x3g7W87yPxcg5fOXCQqx4gKxKLwOzeF6uIdxPX/zmZnGiY+/avfVaBD+FzJZU9/EoaPZ7cuVJIrN3j99TVePPc69x6fYrYxQzw/w/LhIzz7jbN84akL3NgckmSB1Hmy3GNtwIdA7gM2BLxXZLmbWLLHh4D34F1xnQeEgDhPQMjzjNzmQEACIOAlIB4IFIWNDQXwImhVhCatIfeeSCuUCN5D7iCzjv6ow1ZnzPu7Ix555yn2HZjjzMsXsCj6w4RmnuDTG2gdLQtz/9BlL8Q6vvfj3zWgXTr3ccLO4657oxI2t+XlM5dZXV3lHScWqFYbzB4/TrnV5HOfeZovfOMSu4PCUjMUuYc09TgLTiisMnPkYrFBYS1oXyS/ADT+5hEG1zskT97CBE0IHhNFeAc2L2KeUhBC8R8MglMWURCUAu+xsRA7jQ4e7RVaa7wLGAEfCcaDdQ7nNOdWU4b2BjmK97/7Th597B5efeUit9Z3KdeuMGtKlJdilBnM+3jh50Py/HUpv+Ozf17s/twxOk+f/4chDP+OclutsHWZF5/8FhdfP8/xg8ugSyy87V4ygU//5hf56rOr9NKiYkuwWK8YhIw0zyklJayFIIGRTwmhiMXOKPRIIYDDk8UZkoHKDQTIvUVrg0bI8pTCmANgEANUHFiQTJAQQALzP3cv/S9cJz23TSwaLxAFQTTkU47YCTVbIlJQiRXVimZlrsR7793H97z/NNWS8PRTL+PwHD9xgJXTJ4lqNaTRJm7vv6xKjb8t0Qef+vPgp/+sC0J4Qv1X/8U/+1sK+3ck5EvOj+Xm6+d4+ZnneMc9dxBFmqX7HqSfpvzGr36er3z7OoO0sOTUQf/uOoOfnCFvKuy+Eva+Bu7cEJcrSj+8QPk/PESYNuhjNdyrCTQjogeaVD6yjM8g3EgJBJofOUjtP18h+8Y2tfcvUfqxRfKnO+h2idpPHEDNGfTxGnaU4juO8h0NzA/OYVYqVI/Nk7y+hYwCviw0/vsHyJIxctcUai4iXE0QAsEHxllgY2fIzvY287M1Wo0KL758lfW1bUadLabiiN0rV7H97VZc1af/wd//G1/5hX/yr3b/LBz/zNCRjx5/h1H+p1wIR0PIGW/d4tq513jPhx5D0oTqkbdzc22dX/+Vf8M3X9kgyRy59+Q2YL3gn9tlxIDoNYesesLfbZIGT5w5xr+ziWopxr96i6BTtDX4jsX+4ZiyDjDMCM7hg6b76RtMLQvBgo8dw3/8On5YhI3smS1MuQT7NfHxJtmVHbIzI0pnLd3fX2V0ZhtRgg+B+HSbzpMXMH1BASxUyF2X4IsEHPA4MpKXN+n1Mz787pPcc/oQX33yLNvdhJ2tEUdXlli7ui4Hh6P7Fk4e+x/C2i//pCz93c0/DUf1p1vzS/NKqf8kEB4lZLhkl5tnXuDUffdQbdZpnX6U3e6Y3/jE7/H0i+u3k12eB7Lck6aWNHO4isJVFXZa8GmOzzyJS8nagtFCNG0QFWODwiuBdgxTJVS7giyW8KXifvqfXUe9u8bU8RnoB8Bjpko0Hl0gu9bFb+WoRhliTe4taZpiWxqzXINyRMDArsddTcgudBm/tMvgc+skWU5qHWnuGGc5w1HOeifn+Te2+OwXX4GoxgMPHuPG9R3OXd7k3PlVnA9cPndJ7167/i7v1M+G65+q/GlY/jtDRwhPln2q/n2U/1jwoxr5OsnaG7TmZik3m8TtY2x1Rvzax3+Trz63ytgGMmtJ8kCaO9LcF79x8EgbWSphVmpkT++S38hxWlH7vnloRahKgC7Ybk48E1N+qIWslFDTEeWlOnZtTBhZpCNMPX6AW792Dj+wgCaogJ6LKZ+YorzYQEcat5ljOxmogF4uUTrdIux6su0hftsx84FDhDnBHKqjVUR+bYQIhEnUD6HQVXInjJLAaDDk7rsOMtOq8OKL13HKMTtdYXlpFh2VyrWFuaaebl564r/+1IVf+IU/Gc8/MRmGEMSOv/xOUfwjH+S9frSF37kCBCjXUKVZhsOcT/6Pn+T3v3COYWJJHGQuYF3BKHLnyfKAzMVMff8hyuua3WfW6G30aLfa1Bp1kjxj89Y6WZIjQBzHTE9PY72l0+mCCMEHbGZBAtNTM+wMd8F6pttNTBSxvbmDKMX8/CxaCYP+gP6ghw+CswEvDq01jWqNeqOBUoqNWxugAstLi4gHT2DY75CMBkRGUzKacqQKoaqkWGgK7zy9xA/81Xv52tde4ezLl7jrbct874cfpr1/kcrSSjDTBz8jofGfSuXRq38Spn9yjB7+7/M49UNBhce8zRnduIhyGapcyJi5jvnC736Gz335NXq5xzrIckfmIPdC7jy5K0ShmcVZjs8fobRYYrtXYzw75pFHHub1i+dxmWNhdpYzZ16l0ahz7NhRCIHgPMPZId1ul7nZeS5fuswoGXP67jt55tlnePjRB+l0OpTLFdrNFguLC9x1152cOXMW7z1r6zepVqqsrq6ztbXFY489SrlSwuaO3OZMNZv0+z1OnDjF4uI8Fy5c4MY1R7/fR/AoQEm4XfRsDRWvXtrhyGs3+dBH3k+5Wibpd+jlnoX5BSg3JND4gEjt+0N441dFjqd/JtAhPGnSm+ce8sn4h8WI7tzaIt24RVSroBNoTB3j6S99id/57B/RSwPZJOllAbIQyILD6oA1AacEPRYuf+YMG90talNTPP7+v8bD73yEX/nUJzES8cA9b+cDH3w/ooTt7hbP/9HzVOMyD9z/IF4cB1aWSbMRR44e4/rqDT7wwfdRKpf4xre+hXeeQwcOsm/fMrNzczz19W9w+PBhFhbm2bdvH2mWY23Oysohojjidz71uwyGQ+644ySPvfsxvvjFP+C9730fzz79LBKKisdOSnkkTLQTSHPFzU7KK2fXOHrvnXzob/0gl77+h9g8pZdAe7oFRE0n5ke0TZ4Hvvl/x/XfSobp9fOH8p3eTyQbt/b1b21y/ewbdLa6bK9uouszXDr7Mp/97FOs9zKsAWs8aZyT1jzpDOT7BXcixp2M8UcNfp8mb0NSt6yNbhE3Y4L2WJ0x9gNeOf8y9z/8Dg6fXOGbz32TsR2y3d/mhTN/RFQyvPr6WR599yPMLkxz6cYlvvf7PsxnP/+vsRLwIly5fp2z587hgyfPLVevXqPXG/D6629w4sRxPvrDH+Gpr3+DwWBAbh3WOi5cuMypU3fgHXjncNYSPHgvE4kWclsk9GTye5TBpY0BF1+9gotq3PX+D9Fo1hnt7pKMU0JwIoGHvdePh/D67J9q0eHsp+LVa6/cN9re/J5IW9Z3+qxeuE6jEnPgrlMkwxGf+/zXOHtzh7TqSbSQG0MuQuYsufOFYJSnuMwT0oALCe3GFFKa5djJo9x4/Qr3HXsby41ZauUqD93/IF//2lPce9+9hNyhRBCj8d6jRDEepyitMUoRV8o0W1NE5RIhBHCCOCEul2lOTXHs+DFWVg6TpAnPv/ACswvzDIZDtne2cc6xb/8SWZrz2HvexRf+4A8oCN4kASLF+1D87bzHekdqBS0Qa2G7l/Hq+VVO3rhO/a67mVrax/aNG/Sac8TlGlqXRBH/oE3s54E//Hda9Frn/FJ3s/exm9fWKrv9lLMvXWJzs8Mg85SnZ3juxVf45rU1duswquQkjBkNxmRbGe5mTrhm4bKDNzzqUkCueeSWg20Pu57rZ6/z1S/+ITbNkLHHjzwHl1d47tnnOfvSq5w6fALJBeMNjz3yXprNNo8//gO89sYlOp0B8zML/O6/+gzf9z3fB1aBV8xMz/B93/u9RYOWQBxH2NySJGNefe0c33juaQYkBKMIGrxYXjrzMk8/+yxBBKTo8ngKidZ5j3O+0F08OAe584xzxyhxnL+yy7lXXmfU7aBqS4x3u9w69yL9rWuE0MGH5KhS2QdD70szf6JFP/HEE+rq5fX9uxsbj/psJF3ruH5ji6lqxPShg2xvbPLkt86xtjYgHeVkoxw79tg04HLw1hW6cdAoDCIBURoVhJ1ej63dLdLxCOc9165dY31rE60MTz75VUpxiWef/jb33H0373nX+xiPR1y/fp31Wxu4zHLx8jXOyXne9/738OUvfYUTR4/yUz/242R5xtrNNZ755jMcOXqYG9dXiUyMVgotilF/QJpqvHd0kl227Db9tMOV89cIVmGDp9vtIEAIUKgsE71FCd56vPLkDnKn6A8zNrYTnnvuMnecusjBUydQ1TavPv0SUVSh/HZPqTmvJK7+KOXwe8D2Hr636d3a1/7R3PW17d8+9+KL7z98co6vfeMsw81dDiy3eOSDD/Ht5y7w258/y3onIckKJS6zniwvaFQI4AW8GJRolBHEGHQcYY3FSYYjxzvLTGuO9fUNcIqSlPB5wCWWeq1Go97AWcdg0CUQiKIILxGgaE+36HQ7GK2ZabXx3jIaDOn3+1QqNbrdbiEceU+apWijQYGVQLNdY2SGhGpAmsAQQheqeY3B7hB8oQZqUagQUNqjFcRGEceCUYpypJmqlZifLfNX3nuCH/jIuxkOx3ztU79PuV7nofc+yL6jB4jaMx4T/2dR3v+fZf4/Hvwxi37jwvbc7u7mw7g+vWGDm6vbzOjAgWNHGPSGfPuPLrPVScjSYmLIWY/3oYhlQfABRBQSFKINwQghNvhSIK+CqyokilABdvMtzBy4QSBNkmI6TkOv36fX7bHXMTI6AgQdGRDY3d1FgNzn3Ly5ivcem2X44MmyHGsdabbHrApOL0GhYmGQjdAljdYGqwLMg98H44GFdU/Y8ZDKpBQXAhqhkGyt9aAhF2GYWLZ3Rjzz7UvcfXKeY8f20Zqb59lvnaU11UCNB7QXZ1VjZvpvpCKfBd4E+hOf+FjU7W+/e2trq3RwZZlnn30NSVLidp2Z+RYXL65xebVHNtGIXQAbPD5Q3NjkPbmgdEAFQBTEDl8XmFKoVozULF4FvM2JBgGzpUi2PdIvJpScgpAFlBK0iicOV6SRt7brgt+byfOAQitFludFgtz70YD2hDJIPSZqG/yUIa1qtAlIKJqVzlj0gkI1Srhejt3JUYlBTwJJ5h3OFu0x6wpmM0oM128N+eZTZ9nfjFlabFMqR5w9e5npehWfppDbd5i4MhfgskAwAIsdWx7b5Of7uzdU7fS9XL6wwUxD01poY4ddXnzlMtuJxQcpKi7vCXuxLBRCTPCCdwHrcjJnUUERjIc6UDPQjvBtgyoH8FXyXgplTxwLKIXvW5TSmFKFSCKYZH9QeCkarkUsLTQOrQCtUKKx3hYN3D2gjSARqKrCzBj8jCKfFsK0Jy4FHBBGZXQnJ+pppONwY0cQMLMlQh5wg4CMhUhihELDUZHCB0XuoDvMeemNXd5+/ib79rU5dHCOP3r5GkcPd1EkxMZE5anpD4y/8HNn+PA/HRqAtLNWHuno4MrBWa5dXMMYiIxh+cAC3bHj4rUdUltYrcfh/V7S2GugKoIXCExA93jrYQz0QfUt8ZE6lXfdhapEjEcd7GYHe+4mPh1ihgoVYsIwILnHBotWEUqpySzHXrIq0ooSCBIjxhcL7Qt9Gy0ordAlTVzVUFPk7QBzGlnQhGmPLecEFaGyEnLdEnqWNM9gBNoJgQynAroSQ1WRjwPBFhq3C0Vhhi3aZeu7Q156bZXlhQaLi/P4l6/w+sUbLC/eyaA/IKpUf5Yo/5dAAbQvR39TpSkn776LT//WHzBdr1CqxFSrEW9c2mazl5M7bnemi1ARJuAqgi8A2GsfiVYEXbBTLIReIL22jRmnJJEjJBmlwyvIlQF4h5MAHowymEhD0IBCSYSgcExaL3v5W8yE61qyNMVaj1IU42Rq0nkRwAQkFqSmiE8tou9eQY97uKgMCfTOPUnesTASyKSI58SIz3FJTjCCLmtCpAhWFZ8p4BFyGxiMA1duDtncHBBruOOOA6yu90icUM0tziazKuhp4IYC6HZHP5VnO/R6u9xY3UEFy9Rsm9ZUnUtXNhikReduwuzfpEBh8qcA4hElREajdYQxEVprRFRxTe4ZvvoGcb1B/c67CMOE7PIG+a0x+W6GHWY45wuMEbSOJvFZblv27W54CHg81jq88ygpyg3vA856siRh1O8z2u6T3uiSvr7F+Mw1qJYYLCzjF+YYXbsOWY5oQZWFqBqj4hLOQrAanMHnGjcM2MTitYdIIAaJFRhN7oWNfsbV1V1KsaEaGdZv9Th/cY08FPcpxI8994mPGfNrT7y3PNi0x+b313ntzCXSPCfNI5pTVbyHjd0ReaCwYCYuvDdrEQQRVSQOFUAMyhi0VgRjkXLAlz1OeTxgdnLs117GK427uY3qBoI26JJBG42xESELiFJ4pSYsRiAUo1/B2wLktxQVSikQN1l84U1rEMQLYhWSB7g+ZPR7TxHdfRg7TFCXN1AqRqpClGskgyzLkOAxFI3gEEB50BYIDhsHonKMN8XUlBehlwXWdoecOL5ItVymUqtw6eoWD953nCzziNiP7l9Jf82oxNzhbbe0b+U0z33mKSqxIpiIZj3m5s1NtrpJEQND+GOkXiblquDRWhNChJgibKANEhlCZCFyhFJAVctU5vdh5qYwGYxixdhsIZFHjEIsSDAobYrSWBTBTUKAUoV1BDUpmIvwBQGlC2YSQjHLAR4fitihRaF0McLrEzDbUL0yxNRrpKUZhmT4JCHvW1QWIUojWoPzEDyKgAoeYc8rAzk5YgKhrAklw8gHdlNPbzimUtWs7G/y2oUuvbHHuBSj9T1p7mIzHGWPRCqVRqvOjdUO9QhMuUS71eDlszfojwpGsRcm/FsTk4RiJk4JWjRKAcrgZWKNKioijnf4zcD4WzfxpZsIjpAEZKSRcYTKDTqA0TFa6UIj9gGHwwtIJJOCorgJT2HVYTKdtFd3aYQQNME7ggWbeugFJBdULqRZh/RCD+MCJAGGATUSQmYAU1BSQsENxQF5IZv6wnPF+oKCEsjGOXhLIjG9QcbOzpDpdpWlhSrfeGWdq6tblJcrtJSv2pFumDzLHmk1DIPugN5gRK1hKJUi6rUSG9sjkmwP0yL7F8gV7qwk4JUGZVDKg8SI6GIcKxhwCnJBi4AXJAFliq6cdoVLiw0IGgNEQSFeEbxDO4r5CwEXa3xuC7aBJ4Tipdibfiw8LYSCYxffDzgNWSB4XQhQQwixgJtYjROwgnIQvCpYkwiiinEyCXsNqADBI17hULdHIoItAN/aGbDTrXNwZYGcBDGaK9e3OX3sJM6Lzmy+z1ib3dtq19lY26JWiXHBUynH+BDY6YxwYTL8HSgsag/04IrYLIJMxq+CFOMCKkjxoFZQKJQTVFboB0FAB4VMaJtYi/J+MgAzia8hoCZ/egCjERF8cEgA7x3eu+IaKQbX2ZvNo9gdIEKhCdgAQeN9MWYgWgiqQEr8RL1zARyInyyWyETZiyBogjhE2cK7lCq8KfhJyAoMxjmDUY6OYyJlaDVL3NruU240ScZj8U6dNlmWHJ6eP8T5c7doTVXJhwlTtRLjcU53lOGLTQqT5/e3qZwSwatQgCwUi0FhgXrvYX0A61Gu6FZ4EZzssZeACoLyk/pPhAk7nABWLKoTCuUNULcZT8GfCULQ0W0XF1G39cgiMofbsU7cbRKD6D0rLYxHCLcXei8JIm9OsYIC0XgdMFIUTEHC7bSb5p40c2R5IEk9082I9VtDgo4YJ32MUR9Q3tryzPwsN9d3KBkwUcR0q0a/N2YwdhS2UgDIbVlx0nrQhdsKobgpVRQOQRVxW6mC6IsVjBVMHtBZQFvQVjAuFIsxsSTZK7ff8pqswu3FCH7yeFIwoYIPmiJCiypc/rZVF50SgttjoChX3A9WFQM3NmCcoAOo4FHBoyleUEgOxWJJYeDBIqEAmgkkmQuMM09/MGKcOmZbJXqDnOE4J808Sqn3KaMcjVabnc6Qkg6UqmWazQrd/ohR5ibWtbeqE5eU4ru9SJE39tx8L0tOLio4tIIQcMV2E7QLaBtQbi/m7xGygJdQ0LcQcBPvEc9t3dgRCEpQqvAZlJos9FsofnFpMeY7GYIsMmjx2UEKPu5DeNMr9ub2JskwBD8J8gGlNEFN1jISXHCFp0zuGcCFwDhzDIYjHNBqxowyR3d3gEVjczdnYuMxpZj+MCe1I3zFUKuXuba2Q2b9mzpqkQ8I7E14Fg1YE1dwRqEmZaoKkxmGUDCH4CfFxN4D4IowgML7CT+eWLNM4j2T4cY9UUlFBleKiYKGSENq8f0Avhio9n4Sj0WBmgwN3GZGe0bC0ZjEOwAAIABJREFUpOZ68x+EImvuXVJIDLqI9r6YyEYFiMCWHZEUIhoTXWUPGx8K8cnmOUqKjkyWW7q9IZXWFNZZMZEpuGuW5djcEpWhWq3g8nD7wyQEpPC7IvtKKF4esiRDT8X4CjBW4EwRa4NHXHGfHtlzRPbM2E86InvPHbwniJoE6SJIusig6jVKi0vEM5qmlKlUK/T6PW5euIiyFskt2XCIT0f44AtL3sNyj/dLAY4SeQvQTKz2zWtEFSEk7F2nPCEGX0QmXAYmqD8+pDFxI2cDzuaUK2XEQnCONMkx5TI+G2K0mpS2k8pPSTG4nWeFWid4BAfiEBUQNwFfCiJP6sm6CXq6hF5ukA0dYeQnFq7e7MFRfLgohQ8BzVsS1iRcgEf7Qq8w9RrVuTmmDh1k5t6jzOo6bcrEKK7cXGXQGSIhYEJg1O+Rdrvkoz42GU9c3xftLSkyoA+3M+2Ee4e33NckQSomzwvOBKSsCTogowQdachssQ8kNshbEnYRbkJRA5iIJCmENZt7olKZPB1j4lKh/cclTXumxdBpggi59xPLeDM1FRl6kvSCQqSImS5Avp6hbJ/SSoOspKHjUJ0cSQXlNDIpj2US/pQKhbeHwjxEF4ugSxUqM9MsHD7E4eMn2XfiOM1jC5iBQw1y0uGI7WGfcqmCjg1xFGMqNZJak6zfI+l1SHpbhDwtEqXIxHsK5iRKbjMKJaqwZF34XJCAM+DLBl+NCOME1UsJkeB9QOVFey4w8egJvyqwDkRRDFrTGxQhLYpKxCVFFgymUqlP2AEMh2NcbIqkNwkZClUUAMrfTl57feMwCSlFGQysj0m3U1goES1PEQ6UkWHADW1RrCQB7wqkXRCC9WgpBBpdLlFtzTB/4CArJ05y/MRJDhw4SLPdJsyV6N3aJU36JM6jrMcoXWwMMppKrYrSirhcJm400OWY8e42PikmUYuEKaADQU+8SDs0rkiOGiQ2qDgqHCBJ8WtdVOoLplEvEQZZ8fwqcDt2TGxwj7dHcYQPQprYQuyKDSGKyIPGtJq1ojJTijzxWPHYzKG1KrYAq0m8JRSupQRxb5a+YWIlKvaEoHGJh2tD0ptjdL2MqccQm2KxogntsoBziNaYUolopk17/zKHjp7g+Ik7WTm0wsLMHKVSGWU0iZY3haQQsLklyzPKUaVwVw2lUgkJRVFTaU0RvCUJO+TpCG8tSitETQKWFoIuvBGZ8P/UY7tDQmon4UUIRkFNUD7gE4veozhvJaCTX0qgVqswSgM28wQfMJUyDk2aW0y12cRbj9IeFyx57hglKeWyQasiVKi3rJrsWQcBpYoSmjwQSopQAbGC5ApvA2rgMV4RYiGIn8RmjSiDqpWozLSYXlhkanGRgyeOc+TocQ4sHaBVr1PWUdH6xxOCIg+ezFsSW/QIFR7lwVk78dyAdw4/SnBphqlUiZ3HuYB3I5z1KOdRUugnoMhuh7KCCoZJyS2qaMmFkkClhOsk6KIQvB2WC5su5GMtQqQ11VqVze4O43FCFqBarxOcZjCy3tSbjZAmiZTLGqwmc4FklFKvlChrjVbggkJRJBeRtxwCIL5wNSuEvKBBUhGCK7KMdRbjHUaXUMagooi4WqHeajG9vMz+Y0dZPngAXaszs7jAbHuaermKUQbrPTY4vJp4jhKs9wWXFo/oSXG0l8hDMcKlIoNRFfA5JlJEwUNPcHmCeF8odBM2IqGQer2bULmJMogO+NgTaiWMBzd2GF8wD5nE972aQiZAV2JFFCn6gzFZmuIJVGpVtC7jctZMe26ulyXpVGuqwsZwTJLk9LpDarUSZTOpCTyIn2wnk2JPn0JNaJMHF5AxBaEvecQqVCJ45whKqLXnaMzMMDXbZnbfIvtXDnHgwEGWlpYp1Srs2hwTG0qluKgyddH8teIn8qjBhUAaLFYK69NGo8xE9PEBJYqoFBcAWEPwKbk3lJwQx1XyUR+fDPG5xfocFRwy2RvzVvagdKGJ+IpGlTS+m6LyQqXcM+ViCHKPh4PWgWrVEIKn1x1grUMpRbVeRcdVvI6+aKpzrXPDwfid83Ntejt96Dl2BxmH9lWoxAGjwQaFcYXoRQgTyy54J3sqW07RwW5oiAzRKMKPc5y1HDl1ktP3P8C+5SXmluZpz7SpVWuUopgER56MSK2lpBQVE6FFyH3RbfdS6AuOgFdStLUoEqpMRKw92mjEFF2dNJBJQKeaqBIjscPV6rh0RDoc4kZ9SFPwjhBswe+lKJhQAWKFVDU4ix/nmAmwwB8DXCakIdJCs14mzzJ63SE2CJU4Jq7GxFETrUtPGh9H365OmXceOnyQ7bVdrm122OiMOXVkjmbFEPcdeZBCUAkK63UhsLtJNr8tSgRCArplCNMVYtug3Be6tzbxyZh77rqLwyuHqVTiYpuDEjwBE6BsDDtZSp6NKZmoUOpUUdp6mRyWogRlNCEU4wjKFLus1GTLhCBESuNxjIMltx7lA7E2GFNC6g2UmiVLR5S6uyTb24y6u3j8pJgphm0kBsoF/fa9DEmkKFxkb1KvYF1qou8oEWqxYXZuitE4p98Z4pVheqZWKJy6EkpTlTNqOBo8XW/XmFtaoFwy4C2bW0O8c0w1SsSTqldrQeliB6pMpJu9L759A1nADxxS1fiFmIU7jjC7uMir336WqxcuYExEFP3xXqIKgapoKlqzk4xZHfYZOoub6B0KIRJDJBqtFKIUyhjiuEw0WRQ9KX0yldOLEgb5EN8fYTJb3J/RVGo1pmbmmF7cz/TSfkwcESZ5J4pL6DiGWBFKgo8gjDxh+NZSfsK6RCZzfoU1a4FGJWJ2psVuP2XUH+O85sCBOZL+DmmSulq5dkt1d3af1pEEVYpwLqVZi+h0RyRpxnSrSqzAqL391ZP2kEx0ZhQqTF4y0aB7FroW1zIk0xErb7sDo4XPf+Z3uXL1EhpNpKIiiSBEoigrzUxcpolhe9BnYzQgn2jPKkCMUNVFSFG60D5KpertGB2AJHbslsZ0Rx387pAo9ZgwsT6tiEoRpWqZUrlEMhiSDQfgckq1KdoHDhHNtYkXWki9mCnxQw85E/FgEiuCoIK6bWaCYJTQblYolyPWb3VI0pRBajl+8hBZf0TS7+2o5uxQDZ47dy3NhkOJIxqNEoeW2ySZZZh6lhbbxOKKDetaYdTkuAYErQyCRqkIRCOYQgnLPG5tBANLr2KpH1rk2F2nuXr+NT7+j36Rp77yZZI0JVYGozVGC7GGpjHMlcrE1rPb6dFLk4IZ+ICygZqKiLTBKE0Ux5TKZUwpAgLWeHqVlP5wANspNR9RNiWM1kTGEMcxkYmxacbaxYvsXL1AMhwSV2rsu+ttlJeXqB8/SHRgFsoGUg+pm/DpYvxBgkFhUEGjZfIeQ8kYlhdbgLB6dROlhN4459jJgzTKbdJR77nGRjfTv/7VK/5nfuL+95ly86i2OWWB1Y0erZkGCzM1zl+8xdirQtnyk6TkC33ETrYT7/UTQyi6x2SACOWD80RRlfvvvI+ZRouXnn2al577Ni++8DytmTazs3OU4tJk+lPQKJyHUZqxvb5JWSLq1RoGIRunJOOUfDwmHacM+0MUgdQl9OIB/WSArI9pEFErV4niGBPFaBOhjCEZjti4do2t65dJuhsgioUjx5k+eoysJDAVMRzsYrd3CZ0M8qLEVloVLykKuFgpIqOJjSZWwlwz5tH7DlJtVHnxuTeIKjFJUHzoQ/czN72fdJz+4vAKL2qA/+hH70unl/Z/JNaa7ctX2O2OGaSe4ytt1tf77PbyotMSKE4dCBR7tycb4r3d03opyKbXhFFOeb5NeWkGk8BDD76bRx57Ly99+xlefel5nn/mab71ta8z7A+58467Cl3AxERRxPbaOv/nb/wGkXMcWTmOURqb5mRpistSsmHKeDAkyy07tkMn28Gv9ahkJZq1Nsbs9S6LUxN2Nm8x2tlk69plsmEXgrCwcoSj995PJx+hWzHD3i2G167jNofFhFVQxfEUqpjt00qItBBNKuZIC2UjrCxWeeDuJba3+ly4eJNSs8rSyn5OH5ulUlsOSqL/8qGP/fyGAWgsTn/VaOinKbpsmJ+rcfFGH5fDsYPTXFkbkqJROky+1E4aLIJTE+4ZJgJRkKKBOnZ0XrhEZd8SnfYUFy9f4NGH38Uv/Yv/haee/BKf/JV/ztlnv8WFl1/is5/+P3jwkXfx9gcfYpglPPXkl3n5S19hvL7ByROnOXr8ONoHjBRzz+W4RKVSZnV7lc3RGv3Lq0QdRbxYJc/GZEmGzTOyZESWjMkGPbLxAGtzqs0Z7nroYWpzs6zvbhOmNIPeNruXruI2+zDMEV8kayVqkgMmxZAUyXivQo5jYWV/i3Z7ihdfuEJ/7NBOeN+j91ISw6i7c0Vy1YO9sd1hbehN/qVGo/XBw6dPktnznLvU4fJql8P7p5g/v8FgO8fssQ8lGAPWK8QVopL4QsEXlRcifFC49R79s1dJ37VAP/Q5c+4VHnrgYb7/Iz/C4z/w1/mDz/0b/qdf/iWuvHaOGxfO83u/9cmi3M5yvLWcf/55Lrz0IvPzi+A8sXPEPuCzlK7rczPbJFnfQe9a4qjB+tWrBOcLDpLleJdi8wzvPdPz85y69wFm9q2QBsvla5cJDU2aD9i++gZ+u0PopeCKqSg1YRe3ZQcVbh+4Uky7wnQj4vTxBbwybG/32e6lhJplebZOJa4y6g2f2NwebU38HP7bf/7TPgyTcXV29ofG40SSrVv0ugmdXsL9bz/AaDhmbXNA7gTni46C80V7yjtXJORJy8gTCF4hopEgpFtdKivLTO9fpuIUykSUylXqtTqnTt/DD/7QR1haPsSFCxfY3dkiz9JiHJhCSH/p+eeotVr4apOt8YBr3U1e3b3K1a3rDN64QXppk8bUHIPtDm7YhzzBZwl5NkZpzcL+Q9xx/zs5cPJtTC3vY5AMeP3SBUyzgqrBzs3LZGvr2M0R5HsqxuToNylOQjDKY4wm0kJshJKBaqx4+6l5/uq/9xCXL93k289dYOnAFCfuOc6RxRq12kyCqfyTx37sH9+4bdEiH3Vh97eeGdpsYJqtxpG772KcCs+8eJ1UKjz84HGu3hoyujEitx6rFE57cg3GaJz1aOWxkwNKtJaiR0ggjFMuf/HrNA4tMLNvltFwyHavDxhm61VMXOLdf+X7eeB9H+S1V17id37zk5x/9UXyNMV7hRHF+VfPkTXb7GR9Njq7lOOYI9NHmJnOeJV1urfWiGODloJZ1OsNFg8eQtfqlCs12nMLlCo1Nja32Ni6Ra1SpdQssbFzieGtVez2oAA5cFtE2zvJRk+Gg/SkRWVUEaen6yUeeuAUzQPH2fzyGUZjz3SlwiMPn6ZV1ZDbr9WZ2tqThd6yKyvrxqI+Pbe88BOu1ZZ7KmX6otkZjnjoweN8aGTpfuEMV24OMV7QVoiVwqrJWUaqON3Fe3Dii6G1oAtOenOH1a+/wNKPHmSxZhiMu5RLJUQCjXKZslJQjjl5z738vRN30N3Z4tKF89y4fo1Bf0BcrTFcW6XsPUujjDQk2CSj1qyzsLTA5tY2RhvK7Rr1VpvW3CyVep24VKNUqjLOMjZ2t+j2B8S1MqoZszvaZOvGNfz2CEaTqp6iQlSTw69ETfYaaiESiLQmijT1muGOY23e+Z53sLm5y+r16+iypmeh2SyxtO+ATfv5r66eeXXt3wJa2j/RyW78yj8zKnzEmqgxf+IeHoparF29Ql6f5dHH97ORGvqff5F0a0iUa3LtMF4R+UA2KS60DwTlirrJFW1YCbD5jZdYvfsUBz98gLZVjMYjSqWIQTIiAqIoomYiylVDRceUaw32Hz9Fdzhgd9Cj298mG/TwSlNOM4JE4D1H73mQI5Peo9KauFKhUinjvWc8zhgNRwyTMUmeFtOu03X6vsPWzau47S6hm09A5s1CZDLeoBEiJUSTkeA4UjQqMcuzNd733ntoLu/nxjPPsbw4Ry91PPThD7J/5f8q7kxj7CrvM/57l7Pce89d5t7ZPTPebbyBAYfVLDYEQgKhJSWJypJQdYnURG0/VK2UKKJq+6mrVDVt2qRp1SakKanSNBsIAmE3AYyNbbA93mc86527L2fvh3PHJk0oECB9pSP5w0gzfnTO+/7/z/95nncVlpU+ZDr20R1X/4H/M95o8K3UnBGF37Ylv0qqTwxvdHDNHE1hk+sb4rpbU8wudug+dZDFyCWI46Tci0TyiESdL2POCWbOtbBdn1f/9Tv0rxsjd+nlpCsCt9tFpRwUMZVqhSCK0YaJoUz6HIdMysZxMqQdh7STxWu38PvaeJ5P7Af4XZc4TJSkQiQyhCiOaLea1Gs1Gs0mwlCEhARhiHbS+OmI8skz+LPzxAvtRNshErZICJlYQ2QvBEuD0snBbxmatG1QzJtcdskEV37gZsoNj3YQoos54oU6F29fQ6E04MrQ+3srbh99PbY/AXS6/9hcMLfqK1KIW6IwLmpziKEVOZqNBq5XYHBsgJ03VigvNth/4ESScBtFhLEgjGRvCp2oQKMo7MkpegmMcYRfrrL3K9+if+NKRvrX0S374HUx7QypTJaFSpnqwjxKabTWKNNCmTa5bBbLNgi8LK4b0na7hL6L7/p0ui7dbhuv0yZstWnV69SrVcIowrQtAhnRbbsYjo2bM1gqn6B9ZopgrgFeQh4lvLJKKGCZ7MVJUGEvsFBKrOWEmpE877/5apTTT3XqZdLpFLMLFbZt30JpaABtqn0GfT8Whdvbbwi0EPdHcfl7hz1v4b9Et/pJoYvCyeSIIknga7DybLnkKpYWFml3Al597QxBzy2r1bLwRaA4r1shTgabQiRClerewxz6t+8z+rufYGOhSNgI6fguWctmbHCY/myexUqZ2fk5vDAkiELmZufwfQ+hDPxI4fpJ2ea7Hl6ngyAk9n2CrgdRjJVKY9g2bhjQbNWTAYFjUnOXaByfJJheQnSXdRkJx66k6rFxvfJNCXQPZEMrbC0pOCbX7dzM2ot2cPbsKcJmhanjJ2l2JTuvuQQnn/dj4v/E5zD/a/2U6V6UPjhVP/A3XxYqfp+MTm7VfWNks9B1PYLIx7b72H7FldSaLZpdD+/oWXwfoihIpAVR0rQkD+d1Gz0iNw4jDn7te+THBijd+XHGIgev7eFKRSaVIpfL42RyDA+O0O60WFycZ/boEZ747neo12pEQibTkDBAmSkGV4wxtnIluVwfKltA9BRNbhjgeyGu52Pm09TiFrUTk3RPzCFaQU8yIRPORshehZE0X1omjynB0DGmFtiW5pKNw1zzod3U6zVOvvQcbrPJM88f56rrLmV4fDxWMnhERNZDYuD2xpsCDRBmnIO1U6e/oZfKG0rSNXUmhS11z8PRR2lojO2XX0G97VGt1nG9OlGvYTnnpopjeroEYpbdqCTNjB/w0j8+yNjYWvqv2E0+sOgGPjLQOKaJoSVa2dimST6bY3hokP179jB94gRhmJwvQglG1mxlzcZNTIxPoJRB1/fpui6h7xN4Hu1OB6EUXSOkOnOKztFT0PKTM0SBJOGzhUzqZaNnNtLLYCswZJKSMzFocftHd2On4JnvP8yZV/ZxaLqNKAxw+WWbMKU3g6e+avTLV34Wpj8z6qdv9X3VVtv45onXznz31N4X8eZPES8cQ1QPgXcaJVxWrV7LRZdewnU3Xk6xlMHQInGZaoGpFYYyEsZPCbSKex1lQtAIAd2FMk988atMnTiOkbExlSaMziuhpBJoQyVhKaX+cwom0RPEGLaDUyhhpTJo00aZJtowUFoTxhEdr0vbbdM1AqrVGRqTk9Do9FyxoJTE6HHtpooxdLJdmEr0iCOJoSSmUgwVNB+/+ybWrV/Biz94lFeeeo7Dp6pMzgfcvHsb/dmUL9r1R0344RtFIb9h1M+dv/65ypGXn203F2a229LvNwKXxsw0ncVplN/Ayts4uTRut47jZDl1YprAD2FZ6iqWZz7n949YLOs8Ew1eu1ymUa2x48qryaUcZAxa6GROKRMdnpaaVqPBt7/xAEuLiyQ2hxi0jWmnKA6PkC32YVgmETGe79GoN6hWyrRFl7bqUJk8THh2EemFyHPxmfKcpEIrgdaq92/V+6IEhiEp2oJ7PnkTu6/dzOFnn+fJh5+nXG3z9ImQXddewIdvvDQOqjNPW7bzx+bKTx15IzzfMLxq165dQUfqx3645/TDTz9xoFNbqNGp1jm59xX2/uAhTj/9MI43zWqrxYBuc8sNm8naGkuL5FHJY2iJ1rL3GUZoGfc4E0kcRrz25FN8/R++iBf6WKaVCNqXZ5MxmEpyevIorUaT89VuQsh3Ow3CKO5p9pJITdfv0nEbtGnjZ6E1d4ZoagHhBigRYyiFqZN7ArTWSWutde/tTb5InYw9yaUkd3/yRnZfvYmZgwd54qEfM1eu8MwJl2w+xZ23XUVr9tSUX2s/kN44tveNsPw/32iA7z/+ijsyYO8/O1fdoPz2xonxflGvNjh9cpZjh46ivCYFW7PvuX3Mn10ilzVYrLpErzP1iOVpMQl3IHuHpJRJDEQQeMxNTxHHkgu2bUOKRM8p4mQGo4TgwMsv8dyTT9DpdHokT4xlptGGYmLtekoDJSCxvbUadZY6S7TTIa3aAt3DJ5H1dtI+K43WRjJHlInnxugNHwwFhpZJtaEha8Ld93yAG27cjnv2BM88+jxHj8/yakMz3zL4qz+5iwHlttxW5Vsia/xlce0fdn5uoAEOn6k38jnraK3S3J5RrFizekQslSvMzzeYOjNP5HkUsmkOHjhBveFjq5huEBIieyc7PwH4+WFuYl2LRUTotZmbncHK5Vm9fhUmPdF5zwnWqNV49snHaTWbCBGjdIxtWyglWb/tQrKOQxh4tNoNKt0qNcujHbRoHzyCWKigxfKXdR5g3duPDdXr/rRA9fblYs7invtu5Zqd2whnJpk9fpIX9h6j5RR5Yl+DP/r9W7lsc8nvzE0/VpDWZyY+/OWlN8PxTYEGOD3Xnmu6wXR5vnJZMS1LG9aOsrBYxu0EzM+VUVow2JdlerpC2w+RYc86LPX5MXmPqEGQDFhlwlsv2zC6rSblmbMUR0YYWbECFSdpu34QYKdMHn/kB9RqiwkvLCGMPTLZPGsv2IJlmbhem0qnwpJs0VIuzX2Hic/MYoTJ7RVKarTsjeNUUmFoQS9NPUbppM0eLmX4td+4nQ1rBgkWz7BizOGFl49SjTVf+vZpfue33s99H7uS7vTkEdPkzhV3/MvsW8HwLQENxJVmOFlpRc25ufIVpbzpbNowTr3aoNEKWaq3sEzFUClDdamBGyQ2hbin1j/XCPR0E0qI19WuMlGSiphGZZ752WlGJ1ZT7B+EKCAKQ6SCZ3/0CNWFOZRIhJECGJpYxcr164hVRDNqUTM82kZAc9+rhIdPIYMwyTNVqufolb2DLgFcG8mWYRoKy1CsXzPEpz79EdLSJaxNs/GKS3hq7yxHT03x1w8c5qMf2sGf3n933Dy297i5snjd6M6/e8uR9G8VaACaXvRyvRG0y5XqjlLezqwazov5hQqenxA4lhYM9mcIvQDXDdEk5VpEz6e3/DYDCtmrYXvVhVAoIaktzjMzdYoV42MUigVEnOzZJ45NcvbUMYgjZG8/ndi6hRUTI/hGRM0KWaJF9dXDdPZPosMIQybShkQqkdTDUsQoKbC0wjIkdtqkVExz/fXbueveW5g9+hqm12LjZTv4j//ex5HJ/fzzg6e5+fqNfOFvPx0H88ems+snbsiv/vyZt4Pd2wIaoBXyQrur64vzle0ZW+SHB/N0XfdcyrmUglLexhAxra5HYv8IgARQRW/YmRQKKCETbkFyzjBfW5jj9IljOBmHQiGP1hrDkOzfuwff7ybqUdtkw45L0YM5lrTLbG2O6ouv0Nl/BO0nb73WCkMmB9zyzE/rJE3GMhTFosPWLav4yMdv4pqrNnHm1UMMFA1yE2N8+auPMXPqNI/8aJHrr13Pn/3Fb2O55WPZ0U03Gv33HX+7uL1toAGaXvBiIzBemys3r7J0VBgp5UQUJe1uHCX8dD5r4ViKIEyYM0sJVOQnji2RNC9aKRTJBFyr5Zh4hZKKRmWJ/S/soVlZIp02yeUdfvz0U3jdNkpqjEKOwqZ1tL0WC4ePsPD4HsKpeYxYYsikVLOWD7wezaklGIag2Oeweu0IN996Ffd84hYK6YDK7CzrNowyv9jkwQef4vT0WY6c6LL7xi18/rP3+o4VHcmUVl4vch9+W2/y8hJv/iNvvEYH7J3j2dSfbxpWOy6YyCkReURBgIiT2llIgeeGlGsuc9UutZZPN5S0I4Eba5BmkozeSztfdkpFJDa3xFkVoy2LkfExZqbO4LtdYiHJFPOEhklYbxK73Z5HMdm7lUxEj2JZmS8l2jIY6C+wYqKfK953IVdduZlSTlFbPIuybXyvw0vPvsKevcc4NlWn5dvccNMO7r3rplZfVj8pzdxvpku/9HOB/I6BBhgeLqwqaf5m/YC4eutEpq/oGER+kHRdOtkiJJJavcvMYovFRkijExLEgk4U48WSCINQCIK4Z6tD9jyE531+PVMHy5xbTHxO0RkTndNwSxEn9bHuWa2zaXKFDBOrhrjy6u1cuHmUPCFuZRorZeArg5On59nz3CEOTs4yW/FIZUrc+dHr453XXTSVzWYewjY+m83eMf9OcHrHQAOMZrP9KUf+3qo8t60fyWxdP5IWjq3wgwDX9UnZJrat6Lo+S5UW5WqHahM6AcRC0vFDOn5MIAxiKQmFTATkkSCEczlOy17BZKCyrNdOvNumqbEtg1TKJGUrTFNRGiywZctaNm0co88x0H6X1twUKQJyxQIL1Q6vHZ/l1ZOzHDlZIcRi3fpx7viVG/yN21Y9a1rG1x1pfE0U3/ntQu8K0L2VGi3mdxZT0T2r+9VtW1fm8kN5LQI/xHOTS8dhTZF/AAAD10lEQVQyTqp3v6BHpx3SaAd4UYwfgTZshNK03YBq26PZ8QhDENpEGUYSrSZ0cnVICGEc9Nr0GG0K0hmLYl+W8fEhxicGyaQ0Ig6SYKtWG7++RM4ysdMmkYiZmm0wU67z4qEZlGGQMtLs2n1RfO21284Orhz8bmzJL2QK2QPv1n1Z7ybQAKJgM5HPGLcNOuqXJwbSuzaOpIVjJoqmjhvihzGZlEk+ayWNhx/gRYIwlnT9iGbXJxKabC5FPpch42SxbRulgGWzpZYYpoE0km6OOCbwPDzfJ4xifC9KfCS+h23GpC1N2kkRx5qz82XSuRQPPXYQw3YY7s+ydvUYl16xLVi5auDpjCX+Kfbrj6Y3fu5dvXLv3QZ6eVl5w9iWT8d39mf1HauGUmvWjWakLQKa7YhGywelyGdN8mkLJ6OxDIXr+rh+RCwVyjJRSiOUgVSJeUSQlGzKUihtJNlOUS+xJkrCXA0ZY0hJ2jaxbYtYCMq1Dh4hXc/npQNTDBQLjA7mGRsb48JLL/KGV644kO1LfTPsLD2yZ/LfX9q16/Hg3QbkvQJ6efU7mq19jrk7m9b3jpes8fdtLsqMClgodygvtekGCqUVpb40jq0xFDgpjWVKDENhmQaGkqAlSpkoJVGGQhkGWiikjDEtI9GXkKTkLtU6zMzXqbW6OH0mC+UOkyfLrB4tsG68yIrRYS7ceU1YGl55xMykvpgqZJ/FaL4mxAfr7xUQ7zXQy6towJpiwbiqP2ff1eeoiy/elDVGM4JO22Nu3qXeDGl0YzpBIvi2TI1ja/IZg1zGJJOycNIpbFti2SamZaEsi07XZ2ahSrXm0Q18lBak05owjDhzuoyUMN7v0Jc1ufCiDVx8/a5uum/kCTud/pLOjU4a6fRRIbY032sAflFAL6+MDUOFnNE/siJzM57+TD4dDWxZmyNjhNSqLYRK4XYCmo0OHTdMLmUII7xYIpVGKollKrJZm5HRPkqFFEG7TnWpwfxMi6YbYpuKvC3py6ZYvarAjmsvi1du3n5GRsH9A6vX7DOclYvYzAixw3/zP/ndWb9ooF//e9PFVKpYcmQpVzCu9cLwY7YW28aG06nBgqW8jifKS12Wai7tjk8U03OCgTYUlhKkUhrbUsS+R+wnmRyWFvFQwQjXbxirb7ts6wsDI4MP5AvO8wObL66lSs6iEB/8qVj4X9R/+P97CUAPDWFaFuZo2s4LxKgZGdu1FrtsM74upeP+tIVI2SZaSWyl6cuZZDMmpqUiIcSCF4RP+JF4rNMJ92oZnc05mcbaK7d7N42vdcWu+9/1w+3trv8BF648658w3SMAAAAASUVORK5CYII="
STATUS="▌│█║▌║▌║▌│█║▌║▌║▌│█║▌║▌║"
red='\e[1;31m%s\e[0m\n'
green='\e[1;32m%s\e[0m\n'
yellow='\e[1;33m%s\e[0m\n'
blue='\e[1;34m%s\e[0m\n'
magenta='\e[1;35m%s\e[0m\n'
cyan='\e[1;36m%s\e[0m\n'
D_BIT=$(getprop ro.product.cpu.abi)
case $D_BIT in
     "arm64-v8a")
     BIT="64"
     ;;
     "armeabi-v7a")
     BIT="32"
     ;;
     "arm64")
     BIT="64"
     ;;
     "arm")
     BIT="32"
     ;;
     "x86")
     BIT="86"
     ;;
     "x86_64")
     BIT="86_64"
     ;;
     *)
     echo "sorry your device not supported"
     break
     ;;
esac
##################################################################################
##################################################################################
_APP(){
case $1 in
    "app_disable")
		pm disable $PKG_NAME >/dev/null 2>&1
	;;
    
    "enable")
		pm enable $PKG_NAME >/dev/null 2>&1
	;;
	"stop")
		killall $PKG_NAME &>/dev/null
		m force-stop $PKG_NAME &>/dev/null
	;;
	"clean")
		rm -rf /cache/magisk.log*
		rm -rf $OAT_BASE
		rm -rf /sdcard/Android/data/$PKG_NAME/files/UE4Game/ShadowTrackerExtra/{Epic*,Engine}
		rm -rf /sdcard/Android/data/$PKG_NAME/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs*/puffer_temp
		ls -d /sdcard/Android/data/$PKG_NAME/* | grep -v 'files' | xargs rm -rf
		ls -d /sdcard/Android/data/$PKG_NAME/files/* | egrep -v 'ProgramBinaryCache|UE4Game' | xargs rm -rf         
		ls -d /sdcard/Android/data/$PKG_NAME/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/* | grep -v 'Saved' | xargs rm -rf
		ls -d /sdcard/Android/data/$PKG_NAME/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/* | egrep -v 'Config|Paks|PufferEifs|SaveGames' | xargs rm -rf
		ls -d /sdcard/Android/data/$PKG_NAME/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/* | egrep -v 'ODPaks|.pak|.flist' | xargs rm -rf
		ls -d /sdcard/Android/data/$PKG_NAME/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/* | egrep -v 'Active|Layout' | xargs rm -rf        
        echo "✅ free memory : $FREE"        
        echo "✅ clean memory log"
        pm clear com.google.android.webview >/dev/null 2>&1
        echo "✅ clean google webview"
        pm clear com.google.android.gms  >/dev/null 2>&1
        echo "✅ clean game service"
        find -L /data/media/0/ | egrep "magisk|Magisk" | xargs rm -rf
        echo "✅ clean magisk external log"     
        cmd appops set $PKG_NAME RUN_IN_BACKGROUND ignore
        logcat -c
	;;
	"backup")
		mv /sdcard/Android/data/$PKG_NAME /sdcard/Android/data/$PKG_NAME.bak
		mv /sdcard/Android/obb/$PKG_NAME /sdcard/Android/obb/$PKG_NAME.bak
	;;
	"app_clear")
		pm clear $PKG_NAME >/dev/null 2>&1
	;;
	"restore")
		mv /sdcard/Android/data/$PKG_NAME.bak /sdcard/Android/data/$PKG_NAME
		mv /sdcard/Android/obb/$PKG_NAME.bak /sdcard/Android/obb/$PKG_NAME
	;;
	"reinstall")
		pm install -r $APK_BASE >/dev/null 2>&1
	;;
	"touching")
	rm -rf $ROOT_DATA/app_crashrecord
	rm -rf $ROOT_DATA/app_bugly
	rm -rf $ROOT_DATA/files
    rm -rf $ROOT_DATA/code_cache &> /dev/null
    rm -rf $ROOT_DATA/cache &> /dev/null
    touch $ROOT_DATA/app_crashrecord
    touch $ROOT_DATA/app_bugly
    touch $ROOT_DATA/files
    touch $ROOT_DATA/code_cache
    touch $ROOT_DATA/cache &> /dev/null
    chmod 000 $ROOT_DATA/app_crashrecord
    chmod 000 $ROOT_DATA/app_bugly
    chmod 000 $ROOT_DATA/files
    chmod 000 $ROOT_DATA/cache &> /dev/null
    chmod 000 $ROOT_DATA/code_cache
	;;
	"grant_permission")
		pm grant $PKG_NAME android.permission.READ_EXTERNAL_STORAGE
		pm grant $PKG_NAME android.permission.WRITE_EXTERNAL_STORAGE
		pm grant $PKG_NAME android.permission.RECORD_AUDIO
	;;
	"revoke_permission")
		pm revoke $PKG_NAME android.permission.READ_EXTERNAL_STORAGE
		pm grant $PKG_NAME android.permission.WRITE_EXTERNAL_STORAGE
		pm grant $PKG_NAME android.permission.RECORD_AUDIO
	;;
esac
}


##################################################################################
##################################################################################
_DELETE_LIBS(){
for LIBS in libBugly.so libImSDK.so libapp.so libc++_shared.so libflutter.so libgamemaster.so libgcloudarch.so libhelpshiftlistener.so libigshare.so libkk-image.so liblbs.so libmarsxlog.so libmmkv.so libnpps-jni.so libsentry-android.so libsentry.so libsoundtouch.so libst-engine.so libtgpa.so libzip.so
do
rm -rf $LIB/$LIBS
echo -n "🏀"
done
echo ""
}
##################################################################################
##################################################################################
_BACKUP_LIBS(){
mkdir backup &>/dev/null
for BU in libUE4.so libtprt.so libgcloud.so
do
   cp -rf $LIB/$BU backup/$BU
   echo -n "🏈"
done
echo ""
}
##################################################################################
##################################################################################
_RESTORE_LIBS(){
for RS in libUE4.so libtprt.so libgcloud.so
do
rm -rf $LIB/$RS
mv backup/$RS $LIB/$RS
chmod 777 $LIB/$RS
echo -n "🏈"
done
echo ""
}
##################################################################################
##################################################################################
_MEMORY_PROTECTION(){
printf "8192" > /proc/sys/fs/inotify/max_queued_events
printf "8192" > /proc/sys/fs/inotify/max_user_instances
printf "8192" > /proc/sys/fs/inotify/max_user_watches
}
##################################################################################
##################################################################################
_SYSTEM_SECURE(){
setenforce 1 
}
##################################################################################
##################################################################################
_NOTIF(){
_TAG=$1
cmd statusbar expand-notifications &>/dev/null
cmd notification post -I $DATA -S bigtext -t "$_TAG" 'Tag' "$STATUS" &>/dev/null
sleep 3
cmd statusbar collapse  &>/dev/null
}
##################################################################################
##################################################################################
_HIDE_NOTIF(){
service call notification 1 &>/dev/null 
}
##################################################################################
##################################################################################
PROGRESS_BAR(){
CL=""
BAR='##############################'
FILL='------------------------------'
file=$1
totalLines=$(wc -l $file | awk '{print $1}')  # num. lines in file
barLen=30
count=0
while IFS=, read -r _ col1 col2 col3; do
    # update progress bar
    count=$(($count + 1))
    percent=$((($count * 100 / $totalLines * 100) / 100))
    i=$(($percent * $barLen / 100))
    echo -ne "\r[${BAR:0:$i}${FILL:$i:barLen}] $count/$totalLines ($percent%)" | sed 's/#/▇/g'
done <$file
echo ""
}
##################################################################################
##################################################################################
_WAITING_LOGO(){
while [ ! -e $EXT_DATA/files/TGPA ]
do
sleep 1
done
}
##################################################################################
##################################################################################
_WAITING_LOGIN(){
while [ ! -e $EXT_DATA/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Login ]
do
sleep 1
done
}

_FEATURE(){
TOOL="pro_memscan${BIT}"
HACK=$(cat FEATURE/feature.conf)
F_LIB="libUE4.so"
IFS=$'\n'
for hack in $HACK;do
FTR=$(echo $hack |  cut -d ' ' -f1)
STATUS=$(echo $hack |  cut -d ' ' -f2)
if [ "$FTR" == "MAGIC_BULLET" ];then
  if [ "$STATUS" == "ON" ];then
    su -c "./pro_tools/$TOOL $F_LIB F $((0x7009180)) 2.22041217e-17"
  else
    su -c "./pro_tools/$TOOL $F_LIB F $((0x7009180)) 0.10000000149"
  fi
elif [ "$FTR" == "LESS_RECOIL" ];then
  if [ "$STATUS" == "ON" ];then
    su -c "./pro_tools/$TOOL $F_LIB D $((0x282CF34)) 335544357"
  else
    su -c "./pro_tools/$TOOL $F_LIB D $((0x282CF34)) -1275067224"
  fi
elif [ "$FTR" == "AIMBOT_80M" ];then
  if [ "$STATUS" == "ON" ];then
    su -c "./pro_tools/$TOOL $F_LIB D $((0x3CF4FFC)) 505421832"
  else
    su -c "./pro_tools/$TOOL $F_LIB D $((0x3CF4FFC)) 505509889"
  fi
elif  [ "$FTR" == "INSTANT_HIT" ];then
  if [ "$STATUS" == "ON" ];then
    su -c "./pro_tools/$TOOL $F_LIB D $((0x283095C)) 505425152"
  else
    su -c "./pro_tools/$TOOL $F_LIB D $((0x283095C)) 505481216"
  fi
elif [ "$FTR" == "ANIMATION_EFFECT" ];then
  if [ "$STATUS" == "ON" ];then
    su -c "./pro_tools/$TOOL $F_LIB F $((0x7055E58)) 15"
  else
    su -c "./pro_tools/$TOOL $F_LIB F $((0x7055E58)) 0.33333334327"
  fi
elif [ "$FTR" == "WIDE_VIEW" ];then
  if [ "$STATUS" == "ON" ];then
    su -c "./pro_tools/$TOOL $F_LIB F $((0x70A9C58)) 1.4"
    su -c "./pro_tools/$TOOL $F_LIB D $((0x7084684)) 1060320051"
  else
    su -c "./pro_tools/$TOOL $F_LIB F $((0x70A9C58)) 1"
    su -c "./pro_tools/$TOOL $F_LIB F $((0x7084684)) 1"
  fi
fi
done
}

##################################################################################
##################################################################################
_BYPASS_LOGO(){
PKG_NAME=com.tencent.ig
LOGO="true"
if [ "$LOGO" == "true" ];then
if [ "$1" == "logo" ];then
LOGO_CNF="$(cat ./config/logo_offsets.conf)"
NOTIF_STATUS="【﻿ＡＮＴＩＢＡＮ　ＬＯＧＯ　ＳＴＡＲＴ】"
elif [ "$1" == "lobby" ];then
NOTIF_STATUS="𝘼𝙉𝙏𝙄𝘽𝘼𝙉_𝙇𝙊𝘽𝘽𝙔_𝙎𝙏𝘼𝙍𝙏"
LOGO_CNF="$(cat ./config/lobby_offsets.conf)"
fi
pkill -l STOP MainThread-UE4
OLDIFS=$IFS
_NOTIF $NOTIF_STATUS
_NOTIF "PLEASE WAIT, hacking your game....."
for L in $LOGO_CNF;do
IFS=";"
LIBNAME=$(echo $L | awk -F' ' '{print $1}')
TYPE=$(echo $L | awk -F' ' '{print $2}')
OFFSET=$(echo $L | awk -F' ' '{print $3}')
VALUE=$(echo $L | awk -F' ' '{print $4}')
su -c ./pro_tools/pro_memscan$BIT $LIBNAME $TYPE $(($OFFSET)) $VALUE > /dev/null 2>&1
echo -n "#"
logcat -c
done
echo ""
IFS=$OLDIFS
pkill -l CONT MainThread-UE4
_NOTIF "🅰🅽🆃🅸🅱🅰🅽 🅰🅲🆃🅸🆅🅰🆃🅴🅳 ✅"
else
echo "🅱🆈🅿🅰🆂🆂 🅻🅾🅶🅾 ❌ 🤞"
fi
}

_LOBBY_SCRIPT(){
rm -rf $EXT_DATA/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini     
rm -rf backup
for APP in imsdk_inner_webview networkDetector playcore_missing_splits_activity plugin vlink
do
if [ $(pidof $PKG_NAME:$APP) ] ;then
killall -w $PKG_NAME:$APP > /dev/null 2>&1
fi
done

for L in com.twitter.android com.google.android.play.games com.facebook.katana bin.mt.plus bin.mt.plus.canary
do
am force-stop $L > /dev/null 2>&1
done 
}
##################################################################################
##################################################################################
_RUN_APP(){
NAME=$1
PKG="$(cmd package resolve-activity --brief -c android.intent.category.LAUNCHER $NAME | tail -1)"
am start -S -W $PKG >/dev/null 2>&1
}
##################################################################################
##################################################################################
_REPAIR_START(){
APK_BASE="$(pm path $PKG_NAME | cut -d ':' -f2 )"
OAT_BASE="$(pm path $PKG_NAME | cut -d ':' -f2 | sed 's/\/base.apk/\/oat/g')"
LIB="$(pm path $PKG_NAME | awk -F ':' '{print $2}' | sed 's/\/base.apk//g')/lib/arm64"
_APP "app_disable"
_APP "stop"
_MEMORY_PROTECTION
_APP "clean"
_APP "backup"
_APP "app_clear"
_APP "restore"
_APP "reinstall"
_APP "enable"
_APP "grant_permission"
}
##################################################################################
##################################################################################
_INTERNAL_HOST(){
cat > /etc/hosts <<EOF
127.0.0.1    localhost
::1           ip6-localhost
127.0.0.1    1006-shadow.igamecj.com
127.0.0.1    2005-shadow.igamecj.com
127.0.0.1    2006-shadow.igamecj.com
127.0.0.1    2007-shadow.igamecj.com
127.0.0.1    2022523.e0.sched.ovscdns.com
127.0.0.1    3003-shadow.igamecj.com
127.0.0.1    3015-shadow.igamecj.com
127.0.0.1    3021-shadow.igamecj.com
127.0.0.1    3022-shadow.igamecj.com
127.0.0.1    4006-shadow.igamecj.com
127.0.0.1    5004-shadow.igamecj.com
127.0.0.1    5005-shadow.igamecj.com
127.0.0.1    a1845.dscb.akamai.net
127.0.0.1    a1904.v.akamai.net
127.0.0.1    a1967.v.akamai.net
127.0.0.1    api.facebook.com
127.0.0.1    app.adjust.com
127.0.0.1    as-hk.shadow.igamecj.com
127.0.0.1    as-in.shadow.igamecj.com
127.0.0.1    as-mb.shadow.igamecj.com
127.0.0.1    as-sg-m.shadow.igamecj.com
127.0.0.1    as-sg.shadow.igamecj.com
127.0.0.1    asia.csoversea.mbgame.anticheatexpert.com
127.0.0.1    astat.bugly.qcloud.com
127.0.0.1    battlegroundsmobile.kr
127.0.0.1    cdn.wetest.qq.com
127.0.0.1    cdn.wetest.qq.com.cloud.tc.qq.com
127.0.0.1    cdn.wetest.qq.com.sched.legopic2.tdnsv6.com
127.0.0.1    cloud.gsdk.proximabeta.com
127.0.0.1    cloud.vmp.onezapp.com
127.0.0.1    cloudctrl.gcloudsdk.com
127.0.0.1    cs196.wac.edgecastcdn.net
127.0.0.1    cs2-wac-as.8315.ecdns.net
127.0.0.1    cs2-wac.apr-8315.edgecastdns.net
127.0.0.1    cs672.wac.edgecastcdn.net
127.0.0.1    down.anticheatexpert.com
127.0.0.1    down.anticheatexpert.com.akamaized.net
127.0.0.1    down.anticheatexpert.com.cdn.ettdnsv.com
127.0.0.1    e6156.f.akamaiedge.net
127.0.0.1    eu-fra.shadow.igamecj.com
127.0.0.1    eu-mo.shadow.igamecj.com
127.0.0.1    firebaseremoteconfig.googleapis.com
127.0.0.1    googleads.g.doubleclick.net
127.0.0.1    googlehosted.l.googleusercontent.com
127.0.0.1    graph.facebook.com
127.0.0.1    hk.api.unipay.qq.com
127.0.0.1    hk.api.unipay.qq.com.dsa.dnsv1.com
127.0.0.1    hkspeed.igamecj.com
127.0.0.1    idcconfig.gcloudsdk.com
127.0.0.1    ig-us-notice.igamecj.com
127.0.0.1    kj-se.shadow.igamecj.com
127.0.0.1    kj-tk.shadow.igamecj.com
127.0.0.1    lh3.googleusercontent.com
127.0.0.1    me-du.shadow.igamecj.com
127.0.0.1    mgl.lobby.igamecj.com
127.0.0.1    mgl.public.igamecj.com
127.0.0.1    midas.gtimg.cn
127.0.0.1    midas.gtimg.cn.cdn.ettdnsv.com
127.0.0.1    midas.gtimg.cn.cloud.tc.qq.com
127.0.0.1    mkr.lobby.igamecj.com
127.0.0.1    mkr.public.igamecj.com
127.0.0.1    na-centra.shadow.igamecj.com
127.0.0.1    na-east.shadow.igamecj.com
127.0.0.1    na-mx.shadow.igamecj.com
127.0.0.1    na-west.shadow.igamecj.com
127.0.0.1    napubgm.broker.amsoveasea.com
127.0.0.1    nawzryhwatm.broker.amsoveasea.com
127.0.0.1    pandora.game.qq.com
127.0.0.1    pay.igamecj.com
127.0.0.1    local.proxcrypt.com
127.0.0.1    pbs.twimg.com
127.0.0.1    platform-lookaside.fbsbx.com
127.0.0.1    qosidc.gcloudsdk.com
127.0.0.1    sa-sap-m.shadow.igamecj.com
127.0.0.1    sa-sap.shadow.igamecj.com
127.0.0.1    sa-scl.shadow.igamecj.com
127.0.0.1    scontent.fbdo9-1.fna.fbcdn.net
127.0.0.1    scontent.xx.fbcdn.net
127.0.0.1    sg.tdatamaster.com
127.0.0.1    sgspeed.igamecj.com
127.0.0.1    star.c10r.facebook.com
127.0.0.1    www.midasbuy.com
127.0.0.1    www.midasbuy.com.dsa.dnsv1.com
127.0.0.1    www.pubgmobile.com
127.0.0.1    www.pubgmobile.com.cdn.ettdnsv.com
127.0.0.1    www.pubgmobile.com.edgesuite.net
127.0.0.1    ulogs.umeng.com
127.0.0.1    saping.igamecj.com
127.0.0.1    meping.igamecj.com
127.0.0.1    ulogs.umengcloud.com
EOF
if [ $? == 0 ];then
echo "${yel}success replace hosts${end}"
else
echo "${RED}failed replace hosts${end}"
exit 0
fi
}
##################################################################################
##################################################################################
START(){
EXT_DATA="/data/media/0/Android/data/$PKG_NAME"
ROOT_DATA="/data/data/$PKG_NAME"
OBB_DATA="/data/media/0/Android/obb/$PKG_NAME"
APK_BASE="$(pm path $PKG_NAME | cut -d ':' -f2 )"
OAT_BASE="$(pm path $PKG_NAME | cut -d ':' -f2 | sed 's/\/base.apk/\/oat/g')"
LIB="$(pm path $PKG_NAME | awk -F ':' '{print $2}' | sed 's/\/base.apk//g')/lib/arm64"
if [ -f $LIB/libUE4.so ];then
LIB="$(pm path $PKG_NAME | awk -F ':' '{print $2}' | sed 's/\/base.apk//g')/lib/arm64"
G_BIT="64"
else
LIB="$(pm path $PKG_NAME | awk -F ':' '{print $2}' | sed 's/\/base.apk//g')/lib/arm"
G_BIT="32"
fi
G_BIT="64"
echo "$G_BIT BIT"
_ASK_HOST
if [ "$HOST_ACCEPT" == "yes" ];then
_INTERNAL_HOST
fi
_SYSTEM_SECURE
_REPAIR_START
APK_BASE="$(pm path $PKG_NAME | cut -d ':' -f2 )"
OAT_BASE="$(pm path $PKG_NAME | cut -d ':' -f2 | sed 's/\/base.apk/\/oat/g')"
LIB="$(pm path $PKG_NAME | awk -F ':' '{print $2}' | sed 's/\/base.apk//g')/lib/arm64"
if [ -f $LIB/libUE4.so ];then
LIB="$(pm path $PKG_NAME | awk -F ':' '{print $2}' | sed 's/\/base.apk//g')/lib/arm64"
G_BIT="64"
else
LIB="$(pm path $PKG_NAME | awk -F ':' '{print $2}' | sed 's/\/base.apk//g')/lib/arm"
G_BIT="32"
fi
_DELETE_LIBS
_BACKUP_LIBS
_APP "revoke_permission"
_APP "touching"
_RUN_APP $PKG_NAME
_WAITING_LOGO
sleep 1
_BYPASS_LOGO "logo"
_RESTORE_LIBS
_WAITING_LOGIN
sleep 15
_FEATURE
_BYPASS_LOGO "lobby"
_LOBBY_SCRIPT
sleep 1
_HIDE_NOTIF
}
BANNER(){
cat <<EOF
██████╗ ██████╗  ██████╗ ██╗  ██╗
██╔══██╗██╔══██╗██╔═══██╗╚██╗██╔╝
██████╔╝██████╔╝██║   ██║ ╚███╔╝ 
██╔═══╝ ██╔══██╗██║   ██║ ██╔██╗ 
██║     ██║  ██║╚██████╔╝██╔╝ ██╗
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝
 ██████╗██████╗ ██╗   ██╗██████╗ ████████╗
██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
██║     ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
██║     ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
╚██████╗██║  ██║   ██║   ██║        ██║   
 ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
EOF
}
_ASK_HOST(){
echo -n "${yel}USE HOSTS [yes/no]: ${end}"
read -r CONF_HOST
case $CONF_HOST in
     "yes")
       HOST_ACCEPT="yes"
     ;;
     "no")
       HOST_ACCEPT="no"
     ;;
esac
}

EXIT=0
###### START
#PROGRESS_BAR $0
while true;do
until [ $EXIT == 1 ];do
clear
BANNER
PROGRESS_BAR ./config/logo_offsets.conf
printf "$green" "1. ➤ PUBGM GLOBAL"
printf "$red" "2. ➤ PUBGM KOREA"
printf "$yellow" "3. ➤ PUBGM VIETNAM"
printf "$blue" "4. ➤ PUBGM TAIWAN"
echo -n "select options :"
read -r OPT
case $OPT in
   "1")
   PKG_NAME=com.tencent.ig
   echo "$PKG_NAME"
   START   
   ;;
   "2")
   PKG_NAME=com.pubg.krmobile
   echo "$PKG_NAME"
   START
   ;;
   "3")
   PKG_NAME=com.vng.pubgmobile
   echo "$PKG_NAME"
   START
   ;;
   "4")
   PKG_NAME=com.rekoo.pubgm
   echo "$PKG_NAME"
   START
   ;;
   *)
   echo "game not selected"
   ;;
esac
done
done