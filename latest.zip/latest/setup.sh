rm -rf  /sdcard/Pro/latest/log.txt
echo "Installing.." >> /sdcard/Pro/latest/log.txt
echo -e "Detecting Magisk..." >>  /sdcard/Pro/latest/log.txt
su -c magisk -c &> /sdcard/Pro/latest/tmp.list && ( grep -o MAGISK /sdcard/Pro/latest/tmp.list &> /dev/null && echo -e "Magisk is installed..";) || (echo -e "Magisk Not Found or Old Try Manually..";) >>  /sdcard/Pro/latest/log.txt
su -c rm -rf /sdcard/Pro/latest/tmp.list >>  /sdcard/Pro/latest/log.txt
echo -e "Installing Module..." >>  /sdcard/Pro/latest/log.txt
su -c magisk --install-module /sdcard/Pro/latest/module.zip >>  /sdcard/Pro/latest/log.txt
su -c pm install /sdcard/Pro/latest/plugin.apk >>  /sdcard/Pro/latest/log.txt
su -c mv /sdcard/Pro/latest/ver.json /storage/emulated/0/PRO_BOOST/pro_boost/ >>  /sdcard/Pro/latest/log.txt
su -c rm -rf /sdcard/Pro/ >>  /sdcard/Pro/latest/log.txt