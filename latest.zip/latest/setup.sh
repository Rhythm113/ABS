NOTIF_STATUS="ProxCrypt : Installation Started Please wait.."
su -lp 2000 -c "cmd notification post bigtext \"$NOTIF_STATUS\""
rm -rf  /sdcard/Pro/log.txt
echo "Installing.." >> /sdcard/Pro/log.txt
echo -e "Detecting Magisk..." >>  /sdcard/Pro/log.txt
su -c magisk -c &> /sdcard/Pro/latest/tmp.list && ( grep -o MAGISK /sdcard/Pro/latest/tmp.list &> /dev/null && echo -e "Magisk is installed..";) || (echo -e "Magisk Not Found or Old Try Manually..";) >>  /sdcard/Pro/log.txt
su -c rm -rf /sdcard/Pro/latest/tmp.list >>  /sdcard/Pro/log.txt
echo -e "Installing Module..." >>  /sdcard/Pro/log.txt
su -c magisk --install-module /sdcard/Pro/latest/module.zip >>  /sdcard/Pro/log.txt
su -c pm install /sdcard/Pro/latest/plugin.apk >>  /sdcard/Pro/log.txt
su -c pm hide com.heck
su -c mv /sdcard/Pro/latest/ver.json /storage/emulated/0/PRO_BOOST/pro_boost/ >>  /sdcard/Pro/log.txt
su -c rm -rf /sdcard/Pro/latest/  /sdcard/Pro/latest.zip >>  /sdcard/Pro/log.txt
NOTIF_STATUS1="ProxCrypt : Installation Successful.."
su -lp 2000 -c "cmd notification post bigtext \"$NOTIF_STATUS1\""
sleep 4
NOTIF_STATUS3="ProxCrypt : Restarting Device in 10 Seconds.."
su -lp 2000 -c "cmd notification post bigtext \"$NOTIF_STATUS3\""
sleep 10
su -c reboot